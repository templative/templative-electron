# The role of this abstract class is to lay out the functionality needed to take 
# data, artdata, art, and composition information
# and use it to create outputted art files
# and instruction json files
# and the hardcoded component and stokc component information

# Ideally these instruction files are sufficient for uploading, printing, component count, depth, playground, and animation work