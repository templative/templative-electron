# Rules

Play the game.