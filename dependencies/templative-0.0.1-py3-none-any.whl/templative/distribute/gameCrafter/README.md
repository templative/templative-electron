# Game Crafter Client

Expose https://www.thegamecrafter.com/developer/ as a Python package.

When adding stock components, using SKU's provided by adding the stock component to your game, not to your cart, they are different.