class ComponentArtdata:
    def __init__(self, artDataBlobDictionary):
        self.artDataBlobDictionary = artDataBlobDictionary