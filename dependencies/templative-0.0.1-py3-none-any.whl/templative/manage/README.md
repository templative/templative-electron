# Game Manager

Use csvs, json, markdown, and svg templates defining your game to create art files and instructions.