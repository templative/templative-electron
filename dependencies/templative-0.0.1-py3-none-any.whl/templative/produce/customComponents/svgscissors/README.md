# Svg Scissors

Assemble and style svgs out of instructions and convert them into pngs for printing.