class ComponentComposition:
    def __init__(self, gameCompose, componentCompose):
        self.gameCompose = gameCompose
        self.componentCompose = componentCompose