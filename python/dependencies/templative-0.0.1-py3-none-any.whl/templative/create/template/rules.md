# Rules

Play the game.